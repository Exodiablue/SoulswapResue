import React from 'react';
import StakePool from './sections/StakePools';

export default function PoolPage(props) {
  return (
    <>
      <StakePool {...props} />
    </>
  );
}
