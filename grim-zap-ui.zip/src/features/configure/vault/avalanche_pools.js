export const avalanchePools = [];
