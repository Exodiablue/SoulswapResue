export const avalancheZaps = [];
