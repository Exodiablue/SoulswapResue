export const fantomZaps = [];
