import { govPoolABI } from '../abi';

export const fantomStakePools = [];
