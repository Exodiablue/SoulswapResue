import { govPoolABI } from '../abi';

export const bscStakePools = [];
