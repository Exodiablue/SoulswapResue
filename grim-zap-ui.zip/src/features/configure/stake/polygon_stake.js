import { govPoolABI } from '../abi';

export const polygonStakePools = [];
